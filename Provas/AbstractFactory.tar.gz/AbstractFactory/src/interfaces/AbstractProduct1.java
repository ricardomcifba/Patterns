package interfaces;

public interface AbstractProduct1
{
  public void sayHello();
}