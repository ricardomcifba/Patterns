package interfaces;

public interface AbstractProduct2
{
  public void sayHi();
}