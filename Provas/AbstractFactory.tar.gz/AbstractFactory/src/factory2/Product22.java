package factory2;

import interfaces.AbstractProduct2;

public class Product22 implements AbstractProduct2
{
  public void sayHi()
  {
    System.out.println("Produto 2 da fábrica 2");
  }
}