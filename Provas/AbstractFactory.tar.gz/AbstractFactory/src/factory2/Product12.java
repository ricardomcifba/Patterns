package factory2;

import interfaces.AbstractProduct1;

public class Product12 implements AbstractProduct1
{
  public void sayHello()
  {
    System.out.println("Produto 1 da fábrica 2");
  }
}