package factory1;

import interfaces.AbstractProduct2;

public class Product21 implements AbstractProduct2
{
  public void sayHi()
  {
    System.out.println("Produto 2 da fábrica 1");
  }
}