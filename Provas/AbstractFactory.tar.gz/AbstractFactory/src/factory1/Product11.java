package factory1;

import interfaces.AbstractProduct1;

public class Product11 implements AbstractProduct1
{
  public void sayHello()
  {
    System.out.println("Produto 1 da fábrica 1");
  }
}